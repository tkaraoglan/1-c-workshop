# Python Hands-on Trainings

List of hands-on trainings within Python workshop as follows;

- [Hands-on Flask-01 : Creating First Flask Application - Hello World](./flask-01-hello-world-app-on-ec2-linux2/README.md)

